package com.cg.java.services;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
/*
 * afterpropertiesset() this method gets call automatically after all proferties are set
 * 
 */
@Component("empServices")
public class EmpServices {//implements InitializingBean,DisposableBean{
	@Value("Capgemini, Pune")
	private String companyName;
	@Value("Talwade")
	private String address;
	private SalaryServices services;
	private float sal;
	public float getSal() {
		return sal;
	}
	public void setSal(float sal) {
		this.sal = sal;
	}
	public EmpServices(){
		System.out.println("EmpServicesCreated");
	}
	//Properties
	public String getCompanyName() { //companyname
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	//Properties
	public String getAddress() { //address
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMessage(){
		System.out.println(services.calcSalary());
		return "welcome to spring training  " + companyName+" "+address+" "+sal;
	}
	public SalaryServices getServices() {
		return services;
	}
	
	public void setServices(SalaryServices services) { //services
		this.services = services;
	}
	public EmpServices(String companyName, String address, float sal) {
		
		this.companyName = companyName;
		this.address = address;
		this.sal = sal;
	}
	
	@PostConstruct
	public void afterPropertiesSet() throws Exception {
		System.out.println("hello");
	}
	@Autowired
	public EmpServices(SalaryServices services) {
		super();
		this.services = services;
	}
	@PreDestroy
	public void destroy() throws Exception {
		System.out.println("hello ur done");
		
	}
	
	
	
}
