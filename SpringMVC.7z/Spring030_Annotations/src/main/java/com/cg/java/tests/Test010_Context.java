package com.cg.java.tests;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.services.EmpServices;
import com.cg.java.services.SalaryServices;

@SuppressWarnings({ "unused", "deprecation" })
public class Test010_Context {
	/*
	 * The bean and bean tags come from spring-beans.xsd.
	 * The bean tag takes atleast two attributes..
	 *    The class attribute: Represents fully qualified name of class
	 *    the id attribute : To uniquely identify bean
	 *The ClassPathXmlApplicationContext
	 *		is a spring container implementing interface ApplicationContext
	 *On creation of ClassPathXmlApplicationContext...
	 *		Refers the configuration file and creates every bean declared there.
	 *		Beans are of two types : Singleton and Prototype 
	 * 		Singleton : only once object is created
	 * 		Prototype : creates when required
	 * Bean Creation:
	 * 		Eager: All beans are created at the time of creation of Spring Context
	 * 		Lazy: Beans are created on demand
	 * 		Prototype beans are always created lazily
	 * 		Singleton: Eagerly / Lazily.
	 */
	public static void main(String[] args) {
		// 1. Create Spring Context , Spring Context
		// BeanFactory factory = new XmlBeanFactory();
		// The ApplicationContext is modified version of BeanFactory
		// From Spring 4.3 onwards , BeanFactory id deprecated
		ApplicationContext ctx = new ClassPathXmlApplicationContext("springCore.xml");// SpringContainer
		System.out.println("*******");//Eager bean creation : all beans are created at the time of Spring Context
		EmpServices services1 = (EmpServices) ctx.getBean("empServices");
		EmpServices services2 = (EmpServices) ctx.getBean("empServices");//Spring creates a class for u
		//SalaryServices services3 = (SalaryServices) ctx.getBean("salServices");
		System.out.println(services1.getMessage()); 
		System.out.println(services2.getMessage()); 
		//System.out.println(services3.calcSalary());
		((ConfigurableApplicationContext)ctx).close();
		

	}

}
