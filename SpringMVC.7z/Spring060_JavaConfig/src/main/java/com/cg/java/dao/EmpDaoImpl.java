package com.cg.java.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.java.dto.Emp;
@Component("empDao")
public class EmpDaoImpl implements EmpDao{
	public EmpDaoImpl(){
		System.out.println("In EmpDaoImpl class");
	}
	@Override
	public List<Emp> getEmpList() throws Exception{
		List<Emp> empList = new ArrayList<Emp>();
		empList.add(new Emp(123,"surya",1000));
		empList.add(new Emp(124,"bhagavan",2000));
		empList.add(new Emp(125,"ganta",3000));
		return empList;
	}

}
