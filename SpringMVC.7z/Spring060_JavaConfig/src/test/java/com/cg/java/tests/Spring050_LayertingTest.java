package com.cg.java.tests;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.config.ProjectConfig;
import com.cg.java.dao.EmpDao;
import com.cg.java.dao.EmpDaoImpl;
import com.cg.java.services.EmpService;



public class Spring050_LayertingTest {
  public static void main(String[] args){
	  ConfigurableApplicationContext ctx = new AnnotationConfigApplicationContext(ProjectConfig.class);
	  EmpService es1 = ctx.getBean("empService",EmpService.class);
	  EmpService es2 = ctx.getBean("empService",EmpService.class);
	  try {
		System.out.println(es1.getEmpList());
		System.out.println(es2.getEmpList());
	} catch (Exception e) {
		
		e.printStackTrace();
	}
  }
}
