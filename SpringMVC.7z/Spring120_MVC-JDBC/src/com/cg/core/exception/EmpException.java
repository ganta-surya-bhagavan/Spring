package com.cg.core.exception;

public class EmpException extends Exception{
	public EmpException(String msg){
		super(msg);
	}

	public EmpException(String message, Throwable cause) {
		super(message, cause);
	}
}
