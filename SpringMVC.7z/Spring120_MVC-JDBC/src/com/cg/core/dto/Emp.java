package com.cg.core.dto;

public class Emp {
	private int empNo;
	private String eName;
	private int sal;
	public Emp(){}
	public Emp(int empNo, String eName, int sal) {
		super();
		this.empNo = empNo;
		this.eName = eName;
		this.sal = sal;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", eName=" + eName + ", sal=" + sal + "]";
	}
	
}
