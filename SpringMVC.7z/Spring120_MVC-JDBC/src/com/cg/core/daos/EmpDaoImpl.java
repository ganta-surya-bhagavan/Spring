package com.cg.core.daos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.core.dto.Emp;
import com.cg.core.exception.EmpException;
/*
 * Using connection pool is always a best practise insted of managibg single connection
 * Spring support javax.sql.DataSource which is manager for pool of connection
 * A data source in Spring gives ready connection pool and DataSource
 */
public class EmpDaoImpl implements EmpDao  {
	@Autowired
	private DataSource dataSource;
	@Override
	public List<Emp> getEmpList() throws EmpException {
		Connection connect = null;
		Statement stmt = null;
		ResultSet rs =null;
		String qry= "select empNo,eName,sal from emp";
		List<Emp> emp = null;
		try {
			connect = dataSource.getConnection();
			stmt=connect.createStatement();
			rs=stmt.executeQuery(qry);
			while(rs.next()){
				int empNo = rs.getInt("empNo");
				String eName=rs.getString("ename");
				int sal = rs.getInt("sal");
				emp.add(new Emp(empNo,eName,sal));
			}
			return emp;
		} catch (SQLException e) {
			throw new EmpException("Error while retirving data",e);
		}
		finally{
			try {
				rs.close();
				stmt.close();
				connect.close(); //It will not close it will return back to the pool
			} catch (SQLException e) {
				throw new EmpException("Error while closing connection",e);
			}
		}
	}

}
