package com.cg.core.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.core.dto.Emp;

public interface EmpDao {
public List<Emp> getEmpList() throws Exception;
}
