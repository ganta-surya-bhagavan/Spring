package com.cg.core.dto;

public class EmpSal {
	 private int empNo;
	 private float gross;
	 private float deductions;
	 
	 public EmpSal() {
		
	 }

	 public EmpSal(int empNo, float gross, float deductions) {
		
		this.empNo = empNo;
		this.gross = gross;
		this.deductions = deductions;
	 }

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public float getGross() {
		return gross;
	}

	public void setGross(float gross) {
		this.gross = gross;
	}

	public float getDeductions() {
		return deductions;
	}

	public void setDeductions(float deductions) {
		this.deductions = deductions;
	}

	@Override
	public String toString() {
		return "EmpSal [empNo=" + empNo + ", gross=" + gross + ", deductions=" + deductions + "]";
	}
	 
	 
}
