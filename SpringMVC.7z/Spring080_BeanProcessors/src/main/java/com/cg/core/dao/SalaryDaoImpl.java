package com.cg.core.dao;

import org.springframework.stereotype.Component;

@Component
public class SalaryDaoImpl implements SalaryDao{
	
	
}
