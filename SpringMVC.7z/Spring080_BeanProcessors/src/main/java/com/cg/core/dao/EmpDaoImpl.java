package com.cg.core.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.cg.core.dto.Emp;
@Component("empDao")
public class EmpDaoImpl implements EmpDao{
	@Value("10")
	private int val;
	@Autowired
	private SalaryDao dao;
	public EmpDaoImpl(){
		System.out.println("In EmpDaoImpl class ");
	}
	@Override
	public String toString() {
		return "EmpDaoImpl [val=" + val + "]";
	}
	@Override
	public List<Emp> getEmpList() throws Exception{
		List<Emp> empList = new ArrayList<Emp>();
		empList.add(new Emp(100,"surya",5000));
		empList.add(new Emp(101,"bhagavan",5000));
		empList.add(new Emp(102,"ganta",5000));
		return empList;
	}
	

}
