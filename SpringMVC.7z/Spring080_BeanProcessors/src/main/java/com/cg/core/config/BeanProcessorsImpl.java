package com.cg.core.config;

import java.beans.PropertyDescriptor;

import org.springframework.beans.BeansException;
import org.springframework.beans.PropertyValues;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
import org.springframework.stereotype.Component;

import com.cg.core.dao.EmpDao;
import com.cg.core.dao.EmpDaoImpl;
/*
 * The bean processors are created before all other beans
 * The postProcessBeforeInstantation() is called for creating EmpDao
 * If this method returns instance of EmpDaoImpl, bean is created
 * If this method returns null, spring invokes its own bean creation mechanism and creates a bean
 * 
 * BeanPostProcessor
 *     postProcessBeforeInitialization()	
 *     postProcessAfterInstantiation()
 * InstantiationAwareBeanPostProcessor extends from BeanPostProcessor
 * 		postProcessBeforeInstantiation() : Works as object factory
 * 			if it returns null, Spring invokes default object creation mechanism
 *  	postProcessAfterInstantiation()
 *  		return "false" : bypasses data injection . This is called short circuiting
 *  		return "true" : data gets injects 
 *  	postProcessAfterIntialization() :Executed after calling the PostConstruct or
 *               Executed before handling over the object to client. 
 */
@Component
public class BeanProcessorsImpl implements InstantiationAwareBeanPostProcessor{

	//1. 
	public Object postProcessBeforeInstantiation(Class<?> beanClass, String beanName) throws BeansException {
		//Logic to programmatically create a bean can go here
		System.out.println(beanClass.getName() + "  " + beanName);
		if(beanName.equals("EmpDao")){
		EmpDao dao = new EmpDaoImpl();
		return dao;}
		return null;
	}
	@Override
	public boolean postProcessAfterInstantiation(Object bean, String beanName) throws BeansException {
		System.out.println("postProcessAfterInstantiation");
		return true;
	}
	// It comes from BeanPostProcessor. The method can be used to validate injection for the values of a a bean
	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("postProcessBeforeInitialization");
		System.out.println(bean);
		return bean;
	}
	//It comes from bean processor
	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("postProcessAfterInitialization");
		return bean;
	}
	
	@Override
	public PropertyValues postProcessPropertyValues(PropertyValues pvs, PropertyDescriptor[] pds, Object bean,
			String beanName) throws BeansException {
		System.out.println("postProcessPropertyValues()");
		return pvs;
	}
	@Override
	public PropertyValues postProcessProperties(PropertyValues pvs, Object bean, String beanName)
			throws BeansException {
		System.out.println("postProcessProperties()");
		return pvs;
	}

	

	
}
