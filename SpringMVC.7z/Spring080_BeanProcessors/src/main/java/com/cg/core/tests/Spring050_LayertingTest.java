package com.cg.core.tests;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.core.dao.EmpDao;
public class Spring050_LayertingTest {
  public static void main(String[] args){
	  ConfigurableApplicationContext ctx = new ClassPathXmlApplicationContext("springCore.xml");
	  EmpDao es = ctx.getBean(EmpDao.class);
	  
	  ctx.close();
		
  }
}
