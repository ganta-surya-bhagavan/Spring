package com.cg.java.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.java.dto.Emp;
@Component("empDao")
public class EmpDaoImpl implements EmpDao{
	public EmpDaoImpl(){
		System.out.println("In EmpDaoImpl class");
	}
	@Override
	public List<Emp> getEmpList() throws Exception{
		List<Emp> empList = new ArrayList<Emp>();
		empList.add(new Emp(100,"surya",5000));
		empList.add(new Emp(101,"bhagavan",5000));
		empList.add(new Emp(102,"ganta",5000));
		return empList;
	}

}
