package com.cg.java.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.java.dto.Emp;

public interface EmpDao {
public List<Emp> getEmpList() throws Exception;
}
