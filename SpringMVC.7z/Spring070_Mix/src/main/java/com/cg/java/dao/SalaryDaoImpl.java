package com.cg.java.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.java.dto.EmpSal;

public class SalaryDaoImpl implements SalaryDao{
	
	@Override
	public List<EmpSal> getEmpSalList() throws Exception {
		List<EmpSal> empSalList = new ArrayList<EmpSal>();
		empSalList.add(new EmpSal(100,4500,500));
		empSalList.add(new EmpSal(101,4300,700));
		empSalList.add(new EmpSal(102,4400,600));
		return empSalList;
	}
}
