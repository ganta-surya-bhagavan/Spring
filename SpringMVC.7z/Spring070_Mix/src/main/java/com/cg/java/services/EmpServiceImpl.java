package com.cg.java.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.java.dao.EmpDao;
import com.cg.java.dao.SalaryDao;
import com.cg.java.dto.Emp;
import com.cg.java.dto.EmpSal;
@Component("empService")
public class EmpServiceImpl implements EmpService{
	private EmpDao empDao;
	private SalaryDao salaryDao;
	
	public SalaryDao getSalaryDao() {
		return salaryDao;
	}
	@Autowired
	public void setSalaryDao(SalaryDao salaryDao) {
		this.salaryDao = salaryDao;
	}
	public EmpDao getEmpDao() {
		return empDao;
	}
	public EmpServiceImpl(){
		System.out.println("in EmpServiceImpl");
	}
	@Autowired
	public void setEmpDao(EmpDao empDao){
		this.empDao=empDao;
	}
	@Override
	public List<Emp> getEmpList() throws Exception {
		return empDao.getEmpList();
	}
	@Override
	public List<EmpSal> getEmpSalList() {
		
		try {
			return salaryDao.getEmpSalList();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return null;
	}
}
