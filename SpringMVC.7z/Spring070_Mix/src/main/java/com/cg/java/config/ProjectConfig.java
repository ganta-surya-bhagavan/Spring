package com.cg.java.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import com.cg.java.dao.EmpDao;
import com.cg.java.dao.EmpDaoImpl;

@Configuration
@ComponentScan("com.cg.java.services")
@ImportResource("springCore.xml")
public class ProjectConfig {
	//Factory method for EmpDaoImpl
	//@Autowired
	//ApplicationContext ctx;
	@Bean("empDao")
	public EmpDao getEmpDao(){
		System.out.println("bean created");
		return new EmpDaoImpl();
	}
	
}
