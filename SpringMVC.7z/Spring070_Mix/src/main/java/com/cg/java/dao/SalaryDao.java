package com.cg.java.dao;

import java.util.List;

import com.cg.java.dto.EmpSal;

public interface SalaryDao {
	public List<EmpSal> getEmpSalList() throws Exception;
}
