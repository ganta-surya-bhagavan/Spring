package com.cg.java.services;

import java.util.List;

import com.cg.java.dao.EmpDao;
import com.cg.java.dto.Emp;
import com.cg.java.dto.EmpSal;

public interface EmpService {
	public List<Emp> getEmpList() throws Exception;
	public void setEmpDao(EmpDao empDao);
	public List<EmpSal> getEmpSalList();
}
