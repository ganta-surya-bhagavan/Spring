package com.cg.java.services;

import java.util.List;

import com.cg.java.dto.Emp;

public interface EmpService {
	public List<Emp> getEmpList() throws Exception;
}
