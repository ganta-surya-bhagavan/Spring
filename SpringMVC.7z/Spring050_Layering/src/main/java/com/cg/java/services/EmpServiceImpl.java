package com.cg.java.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.java.dao.EmpDao;
import com.cg.java.dto.Emp;
@Component("empService")
public class EmpServiceImpl implements EmpService{
	private EmpDao empDao;
	public EmpServiceImpl(){
		System.out.println("in EmpServiceImpl");
	}
	@Autowired
	public void setEmpDao(EmpDao empDao){
		this.empDao=empDao;
	}
	@Override
	public List<Emp> getEmpList() throws Exception {
		return empDao.getEmpList();
	}
}
