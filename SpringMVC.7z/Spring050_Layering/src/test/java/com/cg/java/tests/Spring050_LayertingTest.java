package com.cg.java.tests;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.dao.EmpDao;
import com.cg.java.dao.EmpDaoImpl;
import com.cg.java.services.EmpService;



public class Spring050_LayertingTest {
  public static void main(String[] args){
	  ApplicationContext ctx = new ClassPathXmlApplicationContext("springCore.xml");// SpringContainer
		System.out.println("*******");//Eager bean creation : all beans are created at the time of Spring Context
		EmpService edi = ctx.getBean("empService",EmpService.class);
		try {
			System.out.println(edi.getEmpList());
		} catch (Exception e) {
			e.printStackTrace();
		}
  }
}
